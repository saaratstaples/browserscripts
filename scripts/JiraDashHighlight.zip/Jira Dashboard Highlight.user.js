// ==UserScript==
// @name         Jira Dashboard Highlight
// @namespace    https://github.com/saaratstaples/browserscripts
// @version      0.1
// @description  Jira Dashboard Highlight
// @author       Saar Picker (saar.picker@staples.com)
// @match        https://jiraent.staples.com/secure/Dashboard.jspa*
// @grant        none
// run-at       document-idle
// ==/UserScript==


(function() {
    'use strict';
    //debugger;

    var highlight_text = function() {
        console.log('Running tampermonkey userscript: dashboard highlight.');

        var elements = document.getElementsByClassName("customfield_21202"); //$('td.customfield_21202');
        console.log('Found ' + elements.length + ' elements.');
        for (var i = 0; i < elements.length; i++) {
            var t = "", e = elements[i];
            try {
                t = e.textContent.trim();
            }
            catch (Exception) {
                // do nothing
            }

            if (t == 'Green') {
                e.style.background = 'green';
                e.style.color = 'white';
            } else if (t == 'Yellow') {
                e.style.background = 'yellow';
                e.style.color = 'black';
            } else if (t == 'Red') {
                e.style.background = 'red';
                e.style.color = 'white';
            } else {
                console.log('Skipping content: "' + t + '"');
            }
        }
        console.log('Done.');
    };

    window.addEventListener('load', function() {
        var timer = setTimeout(highlight_text, 3000);
    }, false);

})();
